package com.example.matchmusic.ViewModel

import androidx.lifecycle.ViewModel
import com.example.matchmusic.Model.Usuario

class UsuarioViewModel() : ViewModel() {
    var me: Usuario? = null
}