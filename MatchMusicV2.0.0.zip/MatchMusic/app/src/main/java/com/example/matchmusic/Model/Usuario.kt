package com.example.matchmusic.Model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity
class Usuario(
    var nome: String,
    var sobrenome: String,
    var pensamento: String? = "Oque está pensando?",
    var sobremim: String? = "Sobre mim.",
    var email: String,
    var senha: String,
    @PrimaryKey(autoGenerate = true)
    var id: Int? = null
) : Serializable {
}