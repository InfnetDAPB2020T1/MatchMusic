package com.example.matchmusic

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.CheckBox
import android.widget.Toast
import androidx.room.Room
import com.example.matchmusic.Database.AppDatabase
import com.example.matchmusic.Database.AppDatabaseService
import com.example.matchmusic.Model.Genero
import com.example.matchmusic.Model.Usuario
import kotlinx.android.synthetic.main.activity_genero.*

class GeneroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_genero)

        val listaGenero = mutableListOf<CheckBox>(
            findViewById(R.id.Rock), findViewById(R.id.Funk),
            findViewById(R.id.Forro), findViewById(R.id.MPB),
            findViewById(R.id.Pop), findViewById(R.id.Eletronica),
            findViewById(R.id.Sertanejo), findViewById(R.id.Samba), findViewById(R.id.Pagode),
            findViewById(R.id.Gospel), findViewById(R.id.Classico), findViewById(R.id.Outro)
        )

        val usuario = intent.getSerializableExtra("usuario") as Usuario

        GeneroButton.setOnClickListener {

            val appDatabase = AppDatabaseService.getInstance(applicationContext)
                /*Room.databaseBuilder(
                applicationContext,
                AppDatabase::class.java,
                "database.sql"
            ).allowMainThreadQueries().build()*/

            guardarGeneros(listaGenero, usuario, appDatabase)
        }
    }

    private fun guardarGeneros(
        listaGenero: MutableList<CheckBox>,
        usuario: Usuario,
        appDatabase: AppDatabase
    ) {
        var contador : Int = 0

        listaGenero.forEach{
            if(it.isChecked){
                val genero = usuario.id?.let { it1 -> Genero(it.text.toString(), it1) }

                if (genero != null) {
                    appDatabase.generoDao().inserirGenero(genero)
                }
                contador += 1
            }
        }
        if(contador >= 3){

            val intt = Intent(this, MainActivity::class.java)
            intt.putExtra("usuario", usuario)
            startActivity(intt)

        } else {
            Toast.makeText(applicationContext,
                "Selecione ao menos 3 generos.",
                Toast.LENGTH_LONG)
                .show()
        }
    }
}
