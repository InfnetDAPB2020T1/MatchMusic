package com.example.matchmusic.Fragments

import android.annotation.SuppressLint
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import androidx.room.Room
import com.example.matchmusic.Database.AppDatabase
import com.example.matchmusic.Database.AppDatabaseService
import com.example.matchmusic.GeneroActivity
import com.example.matchmusic.MainActivity
import com.example.matchmusic.Model.Genero
import com.example.matchmusic.Model.Usuario
import com.example.matchmusic.Model.UsuarioEGenero

import com.example.matchmusic.R
import kotlinx.android.synthetic.main.fragment_login.*

/**
 * A simple [Fragment] subclass.
 */
class LoginFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        criarConta.setOnClickListener {
            findNavController().navigate(R.id.cadastroFragment)
        }

        loginButton.setOnClickListener {
            SetupListTask().execute()

            /*context?.let { it1 ->
                Room.databaseBuilder(
                    it1,
                    AppDatabase::class.java,
                    "database.sql"
                )
                    .allowMainThreadQueries()
                    .build()
            }*/
            //autenticar(appDatabase)
        }
    }

    @SuppressLint("StaticFieldLeak")
    inner class SetupListTask: AsyncTask<
            Unit,
            Unit,
            UsuarioEGenero?
            >(){
        override fun doInBackground(vararg params: Unit): UsuarioEGenero? {
            val appDatabase = context?.let { it1 -> AppDatabaseService.getInstance(it1) }

            val email : String = emailLogin.text.toString()
            val senha : String = senhaLogin.text.toString()

            if(email.isNotEmpty() && senha.isNotEmpty()){
                val userexists = appDatabase?.usuarioDao()?.validarUsuario(email, senha)
                if(userexists?.size == 0){
                    Toast.makeText(context, "Não há nenhuma conta com este email e senha...", Toast.LENGTH_LONG).show()
                } else {
                    var usuario = userexists?.get(0)?.id?.let {
                        appDatabase.usuarioDao().pegarUsuarioeGeneros(
                            it
                        )
                    }
                    return usuario?.get(0)

                    /*val usuario = userexists?.get(0)
                    return usuario*/
                }
            }
            return null
        }

        override fun onPostExecute(result: UsuarioEGenero?) {
            Toast.makeText(context, result?.genero?.tipo, Toast.LENGTH_LONG).show()

            /*val appDatabase = context?.let { it1 -> AppDatabaseService.getInstance(it1) }
            val genreexists = result?.id?.let {
                appDatabase?.generoDao()?.pegarGeneroUsuario(
                    it
                )
            }

            var intt : Intent?

            if(result == null){
                intt = Intent(activity, GeneroActivity::class.java)
            }else{
                intt = Intent(activity, MainActivity::class.java)
            }
            intt.putExtra("usuario", result)
            startActivity(intt)*/
        }
    }
    /*private fun autenticar(appDatabase: AppDatabase?) {
        //var sp = getSharedPreferences("login", MODE_PRIVATE)
        //val sp : SharedPreferences = this.getSharedPreferences("login", MODE_PRIVATE)
        val email : String = emailLogin.text.toString()
        val senha : String = senhaLogin.text.toString()

        if(email.isNotEmpty() && senha.isNotEmpty()){
            val userexists = appDatabase?.usuarioDao()?.validarUsuario(email, senha)
            if(userexists?.size == 0){
                Toast.makeText(context, "Não há nenhuma conta com este email e senha...", Toast.LENGTH_LONG).show()
            } else {
                val genreexists = userexists?.get(0)?.id?.let {
                    appDatabase.generoDao().pegarGeneroUsuario(
                        it
                    )
                }
                var intt : Intent?

                if(genreexists?.size == 0){
                    intt = Intent(activity, GeneroActivity::class.java)
                }else{
                    intt = Intent(activity, MainActivity::class.java)
                }
                intt.putExtra("usuario", userexists?.get(0))
                startActivity(intt)
            }
        }
    }*/

}
