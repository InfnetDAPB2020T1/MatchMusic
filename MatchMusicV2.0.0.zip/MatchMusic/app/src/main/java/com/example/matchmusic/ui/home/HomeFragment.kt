package com.example.matchmusic.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.room.Room
import com.example.matchmusic.Database.AppDatabase
import com.example.matchmusic.Database.AppDatabaseService
import com.example.matchmusic.Model.Usuario
import com.example.matchmusic.R
import com.example.matchmusic.ViewModel.UsuarioViewModel
import kotlinx.android.synthetic.main.fragment_home.*

class HomeFragment : Fragment() {

    private lateinit var homeViewModel: HomeViewModel
    private lateinit var usuarioViewModel: UsuarioViewModel

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_home, container, false)

        activity?.let {
            usuarioViewModel = ViewModelProviders.of(it).get(UsuarioViewModel::class.java)
        }

        /*val textView: TextView = root.findViewById(R.id.text_home)
        homeViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })*/
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var usuario = usuarioViewModel.me

        txtNome.text = usuario?.nome + " " + usuario?.sobrenome
        txtPensamento.text = usuario?.pensamento
        txtSobremim.text = usuario?.sobremim

        btnEditarPerfil.setOnClickListener {
            var appDatabase = context?.let { it1 -> AppDatabaseService.getInstance(it1) }
            usuario?.let { it1 ->
                if (appDatabase != null) {
                    toggleEditor(appDatabase, it1)
                }
            }
        }
    }

    private fun toggleEditor(appDatabase: AppDatabase, usuario: Usuario) {
        if(eTPensamento.visibility == View.VISIBLE && eTSobremim.visibility == View.VISIBLE){
            eTPensamento.visibility = View.GONE
            eTSobremim.visibility = View.GONE

            usuario.pensamento = eTPensamento.text.toString()
            usuario.sobremim = eTSobremim.text.toString()

            appDatabase.usuarioDao().atualizarUsuario(usuario)
            txtPensamento.text = usuario.pensamento
            txtSobremim.text = usuario.sobremim

            txtPensamento.visibility = View.VISIBLE
            txtSobremim.visibility = View.VISIBLE
        }else{
            eTPensamento.visibility = View.VISIBLE
            eTSobremim.visibility = View.VISIBLE

            txtPensamento.visibility = View.GONE
            txtSobremim.visibility = View.GONE
        }
    }
}
